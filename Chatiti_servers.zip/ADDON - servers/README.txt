--Chatiti Server Maker v1.0.0--

How do I create a server from here?
There are many ways that you can open a Chatiti server to chat with your friends, you can:
1. run the CreateServer file and open up a server from there.
2. Go into cmd and type "python", "from source import chatiti_server", "chatiti_server([YOUR IP ADDRESS], [random 4 number string that doesnt start with a 0])"
3. Create a file and write "from source install chatiti_server", "chatiti_server([YOUR IP ADDRESS], [random 4 number string that doesnt start with a 0])"